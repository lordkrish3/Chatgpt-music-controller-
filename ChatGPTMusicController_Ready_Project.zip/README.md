# ChatGPT Music Controller

A small Android starter app for voice-triggered media commands.

## Current features
- Tap-to-speak voice input using Android's installed speech-recognition service.
- Next, previous, play and pause media-button commands.
- Volume up and volume down.
- Opens YouTube Music search pages in Brave for a spoken song or artist name.

## Important limitations
- This starter app listens only after you tap its microphone button. It does not continuously listen in the background.
- It does not receive ChatGPT's private voice transcript.
- Android speech recognition depends on a speech-recognition service installed on the phone.
- Search opens YouTube Music results in Brave. Automatically choosing and starting the first result is not implemented.
- Media commands work only when the active media app accepts Android media-button events.
- Brave's Android package name is set to `com.brave.browser`.

## Build APK online with GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this project folder (not the ZIP file).
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab.
5. Run **Build Android APK** if it has not started automatically.
6. Open the completed workflow run and download the `ChatGPTMusicController-debug` artifact.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow builds a debug APK. It is suitable for personal testing, not Play Store publishing.
