package com.example.chatgptmusiccontroller

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.KeyEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val speechRequest = 10
    private val permissionRequest = 11

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
        }

        val heading = TextView(this).apply {
            text = "ChatGPT Music Controller"
            textSize = 24f
            gravity = Gravity.CENTER
        }

        status = TextView(this).apply {
            text = "Tap the button and say a command."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }

        val listen = Button(this).apply {
            text = "Speak a command"
            setOnClickListener { startListening() }
        }

        layout.addView(heading)
        layout.addView(status)
        layout.addView(listen)
        setContentView(layout)
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), permissionRequest)
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(
                RecognizerIntent.EXTRA_PROMPT,
                "Say next song, previous song, pause, play, volume up, volume down, or play a song name"
            )
        }

        try {
            startActivityForResult(intent, speechRequest)
        } catch (_: Exception) {
            status.text = "No speech-recognition service is available on this phone."
        }
    }

    @Deprecated("Uses the classic activity result API for a compact starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val spoken = data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                .orEmpty()
            status.text = "Heard: $spoken"
            handleCommand(spoken)
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT).trim()
        when {
            command.contains("next") || command.contains("skip") ->
                sendMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT, "Next-track command sent")

            command.contains("previous") || command.contains("go back") ->
                sendMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Previous-track command sent")

            command == "pause" || command.contains("pause music") ->
                sendMediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE, "Pause command sent")

            command == "play" || command.contains("resume") || command == "play music" ->
                sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY, "Play command sent")

            command.contains("volume up") || command.contains("increase volume") -> {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_RAISE,
                    AudioManager.FLAG_SHOW_UI
                )
                status.text = "Volume increased"
            }

            command.contains("volume down") || command.contains("decrease volume") -> {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI
                )
                status.text = "Volume decreased"
            }

            command.startsWith("play ") || command.startsWith("search ") -> {
                val query = command.removePrefix("play ").removePrefix("search ").trim()
                if (query.isNotBlank()) openBraveSearch(query)
                else status.text = "Please say a song or artist name."
            }

            command.contains("open music") || command.contains("youtube music") ->
                openBraveSearch("")

            else ->
                status.text = "Not recognized. Try: next song, pause, or play [song name]."
        }
    }

    private fun sendMediaKey(keyCode: Int, message: String) {
        dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        status.text = "$message. The active media app must accept Android media buttons."
    }

    private fun openBraveSearch(query: String) {
        val url = if (query.isBlank()) {
            "https://music.youtube.com/"
        } else {
            "https://music.youtube.com/search?q=" + URLEncoder.encode(query, "UTF-8")
        }

        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
            setPackage("com.brave.browser")
        }

        try {
            startActivity(intent)
            status.text = if (query.isBlank()) {
                "Opening YouTube Music in Brave"
            } else {
                "Opened YouTube Music search for: $query"
            }
        } catch (_: Exception) {
            status.text = "Brave was not found. Check that Brave is installed."
            Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        ) {
            startListening()
        } else if (requestCode == permissionRequest) {
            status.text = "Microphone permission is required for voice commands."
        }
    }
}
